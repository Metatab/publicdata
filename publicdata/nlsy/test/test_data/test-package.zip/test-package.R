
# Set working directory
# setwd()


new_data <- read.table('test-package.dat', sep=' ')
names(new_data) <- c('R0000100',
  'R0536300',
  'R0536401',
  'R0536402',
  'R1200500',
  'R1200501',
  'R1200600',
  'R1200601',
  'R1220600',
  'R1220700',
  'R1222500',
  'R1222600',
  'R1235800',
  'R1482600',
  'R2395200',
  'R3705700',
  'R3880400',
  'R3880500',
  'R5161200',
  'R5459500',
  'R5459600',
  'R6889500',
  'R6889501',
  'R6889502',
  'S2412400',
  'S2412500',
  'S2412900',
  'S2413000')


# Handle missing values

  new_data[new_data == -1] = NA  # Refused 
  new_data[new_data == -2] = NA  # Dont know 
  new_data[new_data == -3] = NA  # Invalid missing 
  new_data[new_data == -4] = NA  # Valid missing 
  new_data[new_data == -5] = NA  # Non-interview 


# If there are values not categorized they will be represented as NA

vallabels = function(data) {
  data$R0000100[1.0 <= data$R0000100 & data$R0000100 <= 999.0] <- 1.0
  data$R0000100[1000.0 <= data$R0000100 & data$R0000100 <= 1999.0] <- 1000.0
  data$R0000100[2000.0 <= data$R0000100 & data$R0000100 <= 2999.0] <- 2000.0
  data$R0000100[3000.0 <= data$R0000100 & data$R0000100 <= 3999.0] <- 3000.0
  data$R0000100[4000.0 <= data$R0000100 & data$R0000100 <= 4999.0] <- 4000.0
  data$R0000100[5000.0 <= data$R0000100 & data$R0000100 <= 5999.0] <- 5000.0
  data$R0000100[6000.0 <= data$R0000100 & data$R0000100 <= 6999.0] <- 6000.0
  data$R0000100[7000.0 <= data$R0000100 & data$R0000100 <= 7999.0] <- 7000.0
  data$R0000100[8000.0 <= data$R0000100 & data$R0000100 <= 8999.0] <- 8000.0
  data$R0000100[9000.0 <= data$R0000100 & data$R0000100 <= 9999.0] <- 9000.0
  data$R0000100 <- factor(data$R0000100, 
    levels=c(0.0,1.0,1000.0,2000.0,3000.0,4000.0,5000.0,6000.0,7000.0,8000.0,9000.0), 
    labels=c("0",
      "1 TO 999",
      "1000 TO 1999",
      "2000 TO 2999",
      "3000 TO 3999",
      "4000 TO 4999",
      "5000 TO 5999",
      "6000 TO 6999",
      "7000 TO 7999",
      "8000 TO 8999",
      "9000 TO 9999"))
  data$R0536300 <- factor(data$R0536300, 
    levels=c(0.0,1.0,2.0), 
    labels=c("No Information",
      "Male",
      "Female"))
  data$R0536401 <- factor(data$R0536401, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R1200500 <- factor(data$R1200500, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R1200501[1980.0 <= data$R1200501 & data$R1200501 <= 1995.0] <- 1980.0
  data$R1200501 <- factor(data$R1200501, 
    levels=c(1980.0,1996.0,1997.0,1998.0,1999.0), 
    labels=c("1980 TO 1995: 1980 to 1995",
      "1996",
      "1997",
      "1998",
      "1999"))
  data$R1200600 <- factor(data$R1200600, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R1200601[1980.0 <= data$R1200601 & data$R1200601 <= 1995.0] <- 1980.0
  data$R1200601 <- factor(data$R1200601, 
    levels=c(1980.0,1996.0,1997.0,1998.0,1999.0), 
    labels=c("1980 TO 1995: 1980 to 1995",
      "1996",
      "1997",
      "1998",
      "1999"))
  data$R1220600[1.0 <= data$R1220600 & data$R1220600 <= 5.0] <- 1.0
  data$R1220600[6.0 <= data$R1220600 & data$R1220600 <= 10.0] <- 6.0
  data$R1220600[11.0 <= data$R1220600 & data$R1220600 <= 15.0] <- 11.0
  data$R1220600[16.0 <= data$R1220600 & data$R1220600 <= 20.0] <- 16.0
  data$R1220600[21.0 <= data$R1220600 & data$R1220600 <= 25.0] <- 21.0
  data$R1220600[26.0 <= data$R1220600 & data$R1220600 <= 30.0] <- 26.0
  data$R1220600[31.0 <= data$R1220600 & data$R1220600 <= 35.0] <- 31.0
  data$R1220600[36.0 <= data$R1220600 & data$R1220600 <= 40.0] <- 36.0
  data$R1220600[41.0 <= data$R1220600 & data$R1220600 <= 45.0] <- 41.0
  data$R1220600[46.0 <= data$R1220600 & data$R1220600 <= 50.0] <- 46.0
  data$R1220600[51.0 <= data$R1220600 & data$R1220600 <= 999.0] <- 51.0
  data$R1220600 <- factor(data$R1220600, 
    levels=c(0.0,1.0,6.0,11.0,16.0,21.0,26.0,31.0,36.0,41.0,46.0,51.0), 
    labels=c("0: 0 Weeks",
      "1 TO 5: 1-5 Weeks",
      "6 TO 10: 6-10 Weeks",
      "11 TO 15: 11-15 Weeks",
      "16 TO 20: 16-20 Weeks",
      "21 TO 25: 21-25 Weeks",
      "26 TO 30: 26-30 Weeks",
      "31 TO 35: 31-35 Weeks",
      "36 TO 40: 36-40 Weeks",
      "41 TO 45: 41-45 Weeks",
      "46 TO 50: 46-50 Weeks",
      "51 TO 999: 51+ Weeks"))
  data$R1220700[1.0 <= data$R1220700 & data$R1220700 <= 5.0] <- 1.0
  data$R1220700[6.0 <= data$R1220700 & data$R1220700 <= 10.0] <- 6.0
  data$R1220700[11.0 <= data$R1220700 & data$R1220700 <= 15.0] <- 11.0
  data$R1220700[16.0 <= data$R1220700 & data$R1220700 <= 20.0] <- 16.0
  data$R1220700[21.0 <= data$R1220700 & data$R1220700 <= 25.0] <- 21.0
  data$R1220700[26.0 <= data$R1220700 & data$R1220700 <= 30.0] <- 26.0
  data$R1220700[31.0 <= data$R1220700 & data$R1220700 <= 35.0] <- 31.0
  data$R1220700[36.0 <= data$R1220700 & data$R1220700 <= 40.0] <- 36.0
  data$R1220700[41.0 <= data$R1220700 & data$R1220700 <= 45.0] <- 41.0
  data$R1220700[46.0 <= data$R1220700 & data$R1220700 <= 50.0] <- 46.0
  data$R1220700[51.0 <= data$R1220700 & data$R1220700 <= 999.0] <- 51.0
  data$R1220700 <- factor(data$R1220700, 
    levels=c(0.0,1.0,6.0,11.0,16.0,21.0,26.0,31.0,36.0,41.0,46.0,51.0), 
    labels=c("0: 0 Weeks",
      "1 TO 5: 1-5 Weeks",
      "6 TO 10: 6-10 Weeks",
      "11 TO 15: 11-15 Weeks",
      "16 TO 20: 16-20 Weeks",
      "21 TO 25: 21-25 Weeks",
      "26 TO 30: 26-30 Weeks",
      "31 TO 35: 31-35 Weeks",
      "36 TO 40: 36-40 Weeks",
      "41 TO 45: 41-45 Weeks",
      "46 TO 50: 46-50 Weeks",
      "51 TO 999: 51+ Weeks"))
  data$R1222500[1.0 <= data$R1222500 & data$R1222500 <= 5.0] <- 1.0
  data$R1222500[6.0 <= data$R1222500 & data$R1222500 <= 10.0] <- 6.0
  data$R1222500[11.0 <= data$R1222500 & data$R1222500 <= 15.0] <- 11.0
  data$R1222500[16.0 <= data$R1222500 & data$R1222500 <= 20.0] <- 16.0
  data$R1222500[21.0 <= data$R1222500 & data$R1222500 <= 25.0] <- 21.0
  data$R1222500[26.0 <= data$R1222500 & data$R1222500 <= 30.0] <- 26.0
  data$R1222500[31.0 <= data$R1222500 & data$R1222500 <= 35.0] <- 31.0
  data$R1222500[36.0 <= data$R1222500 & data$R1222500 <= 40.0] <- 36.0
  data$R1222500[41.0 <= data$R1222500 & data$R1222500 <= 45.0] <- 41.0
  data$R1222500[46.0 <= data$R1222500 & data$R1222500 <= 50.0] <- 46.0
  data$R1222500[51.0 <= data$R1222500 & data$R1222500 <= 999.0] <- 51.0
  data$R1222500 <- factor(data$R1222500, 
    levels=c(0.0,1.0,6.0,11.0,16.0,21.0,26.0,31.0,36.0,41.0,46.0,51.0), 
    labels=c("0: 0 Weeks",
      "1 TO 5: 1-5 Weeks",
      "6 TO 10: 6-10 Weeks",
      "11 TO 15: 11-15 Weeks",
      "16 TO 20: 16-20 Weeks",
      "21 TO 25: 21-25 Weeks",
      "26 TO 30: 26-30 Weeks",
      "31 TO 35: 31-35 Weeks",
      "36 TO 40: 36-40 Weeks",
      "41 TO 45: 41-45 Weeks",
      "46 TO 50: 46-50 Weeks",
      "51 TO 999: 51+ Weeks"))
  data$R1222600[1.0 <= data$R1222600 & data$R1222600 <= 5.0] <- 1.0
  data$R1222600[6.0 <= data$R1222600 & data$R1222600 <= 10.0] <- 6.0
  data$R1222600[11.0 <= data$R1222600 & data$R1222600 <= 15.0] <- 11.0
  data$R1222600[16.0 <= data$R1222600 & data$R1222600 <= 20.0] <- 16.0
  data$R1222600[21.0 <= data$R1222600 & data$R1222600 <= 25.0] <- 21.0
  data$R1222600[26.0 <= data$R1222600 & data$R1222600 <= 30.0] <- 26.0
  data$R1222600[31.0 <= data$R1222600 & data$R1222600 <= 35.0] <- 31.0
  data$R1222600[36.0 <= data$R1222600 & data$R1222600 <= 40.0] <- 36.0
  data$R1222600[41.0 <= data$R1222600 & data$R1222600 <= 45.0] <- 41.0
  data$R1222600[46.0 <= data$R1222600 & data$R1222600 <= 50.0] <- 46.0
  data$R1222600[51.0 <= data$R1222600 & data$R1222600 <= 999.0] <- 51.0
  data$R1222600 <- factor(data$R1222600, 
    levels=c(0.0,1.0,6.0,11.0,16.0,21.0,26.0,31.0,36.0,41.0,46.0,51.0), 
    labels=c("0: 0 Weeks",
      "1 TO 5: 1-5 Weeks",
      "6 TO 10: 6-10 Weeks",
      "11 TO 15: 11-15 Weeks",
      "16 TO 20: 16-20 Weeks",
      "21 TO 25: 21-25 Weeks",
      "26 TO 30: 26-30 Weeks",
      "31 TO 35: 31-35 Weeks",
      "36 TO 40: 36-40 Weeks",
      "41 TO 45: 41-45 Weeks",
      "46 TO 50: 46-50 Weeks",
      "51 TO 999: 51+ Weeks"))
  data$R1235800 <- factor(data$R1235800, 
    levels=c(0.0,1.0), 
    labels=c("Oversample",
      "Cross-sectional"))
  data$R1482600 <- factor(data$R1482600, 
    levels=c(1.0,2.0,3.0,4.0), 
    labels=c("Black",
      "Hispanic",
      "Mixed Race (Non-Hispanic)",
      "Non-Black / Non-Hispanic"))
  data$R2395200 <- factor(data$R2395200, 
    levels=c(1.0,2.0,3.0), 
    labels=c("White",
      "Black",
      "Other"))
  data$R3705700 <- factor(data$R3705700, 
    levels=c(1.0,2.0,3.0), 
    labels=c("White",
      "Black",
      "Other"))
  data$R3880400 <- factor(data$R3880400, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R3880500 <- factor(data$R3880500, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R5161200 <- factor(data$R5161200, 
    levels=c(1.0,2.0,3.0), 
    labels=c("White",
      "Black",
      "Other"))
  data$R5459500 <- factor(data$R5459500, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R5459600 <- factor(data$R5459600, 
    levels=c(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0), 
    labels=c("1: January",
      "2: February",
      "3: March",
      "4: April",
      "5: May",
      "6: June",
      "7: July",
      "8: August",
      "9: September",
      "10: October",
      "11: November",
      "12: December"))
  data$R6889500 <- factor(data$R6889500, 
    levels=c(0.0,1.0), 
    labels=c("NOT SELECTED",
      "White"))
  data$R6889501[1.0 <= data$R6889501 & data$R6889501 <= 2.0] <- 1.0
  data$R6889501 <- factor(data$R6889501, 
    levels=c(0.0,1.0), 
    labels=c("NOT SELECTED",
      "Black or African American"))
  data$R6889502[1.0 <= data$R6889502 & data$R6889502 <= 3.0] <- 1.0
  data$R6889502 <- factor(data$R6889502, 
    levels=c(0.0,1.0), 
    labels=c("NOT SELECTED",
      "Asian"))
  data$S2412400 <- factor(data$S2412400, 
    levels=c(0.0,1.0), 
    labels=c("0: 0  CONDITION DOES NOT APPLY",
      "1: 1  CONDITION APPLIES"))
  data$S2412500 <- factor(data$S2412500, 
    levels=c(0.0,1.0), 
    labels=c("0: 0  CONDITION DOES NOT APPLY",
      "1: 1  CONDITION APPLIES"))
  data$S2412900 <- factor(data$S2412900, 
    levels=c(0.0,1.0), 
    labels=c("0: 0  CONDITION DOES NOT APPLY",
      "1: 1  CONDITION APPLIES"))
  data$S2413000 <- factor(data$S2413000, 
    levels=c(0.0,1.0), 
    labels=c("0: 0  CONDITION DOES NOT APPLY",
      "1: 1  CONDITION APPLIES"))
  return(data)
}

varlabels <- c("PUBID - YTH ID CODE 1997",
  "KEY!SEX (SYMBOL) 1997",
  "KEY!BDATE M/Y (SYMBOL) 1997",
  "KEY!BDATE M/Y (SYMBOL) 1997",
  "CV_CHILD_BIRTH_DATE L1 1997",
  "CV_CHILD_BIRTH_DATE L1 1997",
  "CV_CHILD_BIRTH_DATE L2 1997",
  "CV_CHILD_BIRTH_DATE L2 1997",
  "CV_WKSWK_JOB_YR L1,80 1997",
  "CV_WKSWK_JOB_YR L1,81 1997",
  "CV_WKSWK_JOB_YR L2,80 1997",
  "CV_WKSWK_JOB_YR L2,81 1997",
  "CV_SAMPLE_TYPE 1997",
  "KEY!RACE_ETHNICITY (SYMBOL) 1997",
  "INT REM RS RACE 1998",
  "INT REM RS RACE 1999",
  "CV_CHILD_BIRTH_DATE L1 1999",
  "CV_CHILD_BIRTH_DATE L2 1999",
  "INT REM RS RACE 2000",
  "CV_CHILD_BIRTH_DATE L1 2000",
  "CV_CHILD_BIRTH_DATE L2 2000",
  "INT REM RS RACE 2001",
  "INT REM RS RACE 2001",
  "INT REM RS RACE 2001",
  "CHK WHO RCV FIN AID FROM L1,1,1 2003",
  "CHK WHO RCV FIN AID FROM L1,1,2 2003",
  "CHK WHO RCV FIN AID FROM L1,2,1 2003",
  "CHK WHO RCV FIN AID FROM L1,2,2 2003"
)


# Use qnames rather than rnums

qnames = function(data) {
  names(data) <- c("PUBID_1997",
    "KEY_SEX_1997",
    "KEY_BDATE_M_1997",
    "KEY_BDATE_Y_1997",
    "CV_CHILD_BIRTH_DATE.01_M_1997",
    "CV_CHILD_BIRTH_DATE.01_Y_1997",
    "CV_CHILD_BIRTH_DATE.02_M_1997",
    "CV_CHILD_BIRTH_DATE.02_Y_1997",
    "CV_WKSWK_JOB_YR.01.80_1997",
    "CV_WKSWK_JOB_YR.01.81_1997",
    "CV_WKSWK_JOB_YR.02.80_1997",
    "CV_WKSWK_JOB_YR.02.81_1997",
    "CV_SAMPLE_TYPE_1997",
    "KEY_RACE_ETHNICITY_1997",
    "YIR-520_1998",
    "YIR-520_1999",
    "CV_CHILD_BIRTH_DATE.01~M_1999",
    "CV_CHILD_BIRTH_DATE.02~M_1999",
    "YIR-520_2000",
    "CV_CHILD_BIRTH_DATE.01~M_2000",
    "CV_CHILD_BIRTH_DATE.02~M_2000",
    "YIR-520~000001_2001",
    "YIR-520~000002_2001",
    "YIR-520~000003_2001",
    "YSCH-24400.01.01.01_2003",
    "YSCH-24400.01.01.02_2003",
    "YSCH-24400.01.02.01_2003",
    "YSCH-24400.01.02.02_2003")
  return(data)
}


#********************************************************************************************************

# Remove the '#' before the following line to create a data file called "categories" with value labels. 
#categories <- vallabels(new_data)

# Remove the '#' before the following lines to rename variables using Qnames instead of Reference Numbers
#new_data <- qnames(new_data)
#categories <- qnames(categories)

# Produce summaries for the raw (uncategorized) data file
summary(new_data)

# Remove the '#' before the following lines to produce summaries for the "categories" data file.
#categories <- vallabels(new_data)
#summary(categories)

#************************************************************************************************************

